var http = require('http');
var fs = require("fs");
var qs = require('querystring');
//var express = require('express');
//var app = express();

//app.set('view engine','ejs');
//app.use('/public',express.static('public'));

//app.get('/',function(req,res){
//	res.render('index');
//}

//app.get('/contact',function(req, res){
//	res.render('contact');
//}
//app.get('/',function(req,res) {
//	res.sendFile(__dirname + '/index.html');
//});

//app.get('/css/shop-homepage.css',function(req,res) {
//	res.sendFile(__dirname + '/index.html');
//});

//app.listen(3000, function(){
//	console.log('Example app listening on port 3000!');
//}

var MongoClient = require('mongodb').MongoClient;

var dbUrl = "mongodb://localhost:27017/";



http.createServer(function(request, response) {

	if(request.url === "/index"){
//		sendFileContent(response, "./Home/index.html", "text/html");
		sendFileContent(response, "web.html", "text/html");
} else if
(request.url === "/register1"){
	//		sendFileContent(response, "./Home/index.html", "text/html");
			sendFileContent(response, "register.html", "text/html");
}

  else if(request.url === "/home"){
		sendFileContent(response, "Home/index.html", "text/html");

}
  else if(request.url === "/success"){
	sendFileContent(response, "Home_success/index_success.html", "text/html");

}
//  else if(request.url === "/fav"){
//  sendFileContent(response, "fav/fav.html", "text/html");

//}


	else if(request.url === "/"){
		console.log("Requested URL is url" +request.url);
		response.writeHead(200, {'Content-Type': 'text/html'});
		response.write('<b>Hey there!</b><br /><br />This is the default response. Requested URL is: ' + request.url);
	}
//	else if(req.url.match("./Home/css$")){
//		var cssPath = path.join(_dirname,'Home',req.url);
//		var fileStream = fs.createReadStream(cssPath,"UTF-8");
//		res.writeHead(200,{"Conten-Type":"text/css"});
//		fileStream.pipe(res);
//	}

    else if(request.url==="/test"){

        if (request.method === "POST") {
            console.log("test");
        formData = '';
        msg = '';
        return request.on('data', function(data) {
          formData += data;
          console.log(formData);
          return request.on('end', function() {
            var user;
            user = qs.parse(formData);
            user.id = "123456";

            msg = JSON.stringify(user);

            info=formData.split("&");

            for(i=0; i<info.length; i++){

                var d=info[i].split("=");

            }

            console.log(d[0]);
            console.log(d[1]);

            stringMsg = JSON.parse(msg);
            MongoClient.connect(dbUrl, function(err, db) {

  					if (err) throw err;

  					var dbo = db.db("mydb");

  					var myobj = stringMsg;

  					dbo.collection("customers").insertOne(myobj, function(err, res) {

    				if (err) throw err;

    				console.log("1 document inserted");

    				db.close();

  					});

					});


           // request.writeHead(200, {
            //  "Content-Type": "application/json",
            //  "Content-Length": msg.length
           // });
            //return request.end("okok");
            response.end("okokss");
          });

        });

      }
	}
	else if(request.url==="/success"){

	        if (request.method === "POST") {
	            console.log("test");
	        formData = '';
	        msg = '';
	        return request.on('data', function(data) {
	          formData += data;
	          console.log(formData);
	          return request.on('end', function() {
	            var user;
	            user = qs.parse(formData);
	            user.id = "123456";
	            msg = JSON.stringify(user);

	            info=formData.split("&");

	            for(i=0; i<info.length; i++){

	                var d=info[i].split("=");

	            }

	            console.log(d[0]);
	            console.log(d[1]);

	            stringMsg = JSON.parse(msg);
	            MongoClient.connect(dbUrl, function(err, db) {

	  					if (err) throw err;

	  					var dbo = db.db("mydb");

	  					var myobj = stringMsg;

	  					//dbo.collection("customers").findOne({}, function(err, result) {
	                    dbo.collection("customers").find({}).toArray(function(err, result) {
	    				if (err) throw err;

	    				console.log(result);

	    				db.close();

							if(result != null) {
							  console.log("login Success");
								response.end("login Success");
							}else{
								console.log("login fail");
								response.log("login fail");
							}



	  					});

						});


	           // request.writeHead(200, {
	            //  "Content-Type": "application/json",
	            //  "Content-Length": msg.length
	           // });
	            //return request.end("okok");
	            response.end("login success");
	          });

	        });

	      }
		  else {
	        //form = publicPath + "ajaxSignupForm.html";
	//        sendFileContent(response, "index.html", "text/html");
	        sendFileContent(response, "index_success.html", "text/html");
	//				sendFileContent(response, "index.html", "text/html");

	      }



	 	}
else if(request.url==="/login"){

        if (request.method === "POST") {
            console.log("test");
        formData = '';
        msg = '';
        return request.on('data', function(data) {
          formData += data;
          console.log(formData);
          return request.on('end', function() {
            var user;
            user = qs.parse(formData);
            user.id = "123456";
            msg = JSON.stringify(user);

            info=formData.split("&");
            //console.log(info[0]);
						//console.log(info[1]);

						var d=info[0].split("=");  //login=xxx
						console.log(d[1]); //xxxx


						var p=info[1].split("=");  //password=yyy
 					 console.log(p[1]); //yyy



          /*  for(i=0; i<info.length; i++){

                var d=info[i].split("=");

            }*/

            //console.log(d[0]);
            //console.log(d[1]);

            stringMsg = JSON.parse(msg);
            MongoClient.connect(dbUrl, function(err, db) {

  					if (err) throw err;

  					var dbo = db.db("mydb");

  					var myobj = stringMsg;
            //var query = { loginname: d[1], password: p[1] };
						var query = { loginname: d[1], password: p[1] };
						console.log(query);
  					//dbo.collection("customers").findOne({}, function(err, result) {
                    dbo.collection("customers").find(query).toArray(function(err, result) {
    				if (err) throw err;

    				console.log(result.length);
						if(result.length>0){
                 response.end("login success");

						}else{

							    response.end("wrong password or username");
						}

    				db.close();

					/*	if(result != null) {
						  console.log("login success");
							response.end("login success");
						}else{
							console.log("login fail");
							response.log("login fail");
						}*/



  					});

					});


           // request.writeHead(200, {
            //  "Content-Type": "application/json",
            //  "Content-Length": msg.length
           // });
            //return request.end("okok");
            //response.end("okokss");
          });

        });

      }
	  else {
        //form = publicPath + "ajaxSignupForm.html";
//        sendFileContent(response, "index.html", "text/html");
        sendFileContent(response, "web.html", "text/html");
//				sendFileContent(response, "index.html", "text/html");

      }



 	}
	else if(request.url==="/register"){

	        if (request.method === "POST") {
	            console.log("test");
	        formData = '';
	        msg = '';
	        return request.on('data', function(data) {
	          formData += data;
	          console.log(formData);
	          return request.on('end', function() {
	            var user;
	            user = qs.parse(formData);
	            user.id = "123456";
	            msg = JSON.stringify(user);

	            info=formData.split("&");

	            for(i=0; i<info.length; i++){

	                var d=info[i].split("=");

	            }

	            console.log(d[0]);
	            console.log(d[1]);

	            stringMsg = JSON.parse(msg);
	            MongoClient.connect(dbUrl, function(err, db) {

	  					if (err) throw err;

	  					var dbo = db.db("mydb");

	  					var myobj = stringMsg;

	  					//dbo.collection("customers").findOne({}, function(err, result) {
	            dbo.collection("customers").insertOne(myobj, function(err,res) {
	    				if (err) throw err;

	    				console.log("register successful");

	    				db.close();

	  					});

						});


	           // request.writeHead(200, {
	            //  "Content-Type": "application/json",
	            //  "Content-Length": msg.length
	           // });
	            //return request.end("okok");
	            response.end("register successful");
	          });

	        });

	      }
		  else {
	        //form = publicPath + "ajaxSignupForm.html";
	//        sendFileContent(response, "index.html", "text/html");
	        sendFileContent(response, "register.html", "text/html");
	//				sendFileContent(response, "index.html", "text/html");

	      }



	 	}
		else if(request.url==="/fav"){

		        if (request.method === "POST") {
		            console.log("test fav");
		        formData = '';
		        msg = '';
		        return request.on('data', function(data) {
		          formData += data;
		          console.log(formData);
		          return request.on('end', function() {
		            var user;
		            user = qs.parse(formData);
		            user.id = "123456";
		            msg = JSON.stringify(user);

		            info=formData.split("&");

		            for(i=0; i<info.length; i++){

		                var d=info[i].split("=");

		            }

		            console.log(d[0]);
		            console.log(d[1]);

		            stringMsg = JSON.parse(msg);
		            MongoClient.connect(dbUrl, function(err, db) {

		  					if (err) throw err;

		  					var dbo = db.db("mydb");

		  					var myobj = stringMsg;

		  					//dbo.collection("customers").findOne({}, function(err, result) {
		                    dbo.collection("fav").insertOne(myobj, function(err,res) {
		    				if (err) throw err;

		    				console.log("1 document inserted");

		    				db.close();

		  					});

							});


		           // request.writeHead(200, {
		            //  "Content-Type": "application/json",
		            //  "Content-Length": msg.length
		           // });
		            //return request.end("okok");
		            response.end("okokss");
		          });

		        });

		      }
			  else {
		        //form = publicPath + "ajaxSignupForm.html";
		//        sendFileContent(response, "index.html", "text/html");
		        sendFileContent(response, "fav/fav.html", "text/html");
		//				sendFileContent(response, "index.html", "text/html");

		      }



		 	}
			else if(request.url==="/deletefav"){

			        if (request.method === "POST") {
			            console.log("deletefav");
			        formData = '';
			        msg = '';
			        return request.on('data', function(data) {
			          formData += data;
			          console.log(formData);
			          return request.on('end', function() {
			            var user;
			            user = qs.parse(formData);
			            user.id = "123456";
			            msg = JSON.stringify(user);

			            info=formData.split("&");

									var d=info[0].split("=");  //user=xxx
			 						console.log(d[1]); //xxxx


			 						var p=info[1].split("=");  //content=yyy
			  					 console.log(p[1]); //yyy



			            stringMsg = JSON.parse(msg);
			            MongoClient.connect(dbUrl, function(err, db) {

			  					if (err) throw err;

			  					var dbo = db.db("mydb");

			  					var myobj = stringMsg;
									var myquery = { userid: d[1], content: p[1]};

			  					//dbo.collection("customers").findOne({}, function(err, result) {
			            dbo.collection("fav").deleteOne(myquery, function(err,res) {
			    				if (err) throw err;

			    				console.log("1 document deleted");

			    				db.close();

			  					});

								});


			           // request.writeHead(200, {
			            //  "Content-Type": "application/json",
			            //  "Content-Length": msg.length
			           // });
			            //return request.end("okok");
			            response.end("okokss");
			          });

			        });

			      }
				  else {
			        //form = publicPath + "ajaxSignupForm.html";
			//        sendFileContent(response, "index.html", "text/html");
			        sendFileContent(response, "fav.html", "text/html");
			//				sendFileContent(response, "index.html", "text/html");

			      }



			 	}
				else if(request.url==="/loadfav"){

				        if (request.method === "POST") {
				            console.log("test");
				        formData = '';
				        msg = '';
				        return request.on('data', function(data) {
				          formData += data;
				          console.log(formData);
				          return request.on('end', function() {
				            var fav;
				            user = qs.parse(formData);
				            user.id = "content";     //@@@@@@@@@@@@@@@@@@
				            msg = JSON.stringify(user);



				          /*  for(i=0; i<info.length; i++){

				                var d=info[i].split("=");

				            }*/

				            //console.log(d[0]);
				            //console.log(d[1]);

				            stringMsg = JSON.parse(msg);
				            MongoClient.connect(dbUrl, function(err, db) {

				  					if (err) throw err;

				  					var dbo = db.db("mydb");

				  					var myobj = stringMsg;
				            //var query = { loginname: d[1], password: p[1] };
										var query = { "userid" : "alex"}; //@@@@@@@@@@@@
										console.log("sss="+query);
				  					//dbo.collection("customers").findOne({}, function(err, result) {
				                    dbo.collection("fav").find(query).toArray(function(err, result) {
				    				if (err) throw err;

				    				console.log(result);
										if(result.length>0){
				                 response.end(JSON.stringify(result));

										}else{

											    response.end("login fail");
										}

				    				db.close();

									/*	if(result != null) {
										  console.log("login success");
											response.end("login success");
										}else{
											console.log("login fail");
											response.log("login fail");
										}*/



				  					});

									});


				           // request.writeHead(200, {
				            //  "Content-Type": "application/json",
				            //  "Content-Length": msg.length
				           // });
				            //return request.end("okok");
				            //response.end("okokss");
				          });

				        });

				      }
					  else {
				        //form = publicPath + "ajaxSignupForm.html";
				//        sendFileContent(response, "index.html", "text/html");
				console.log("load page");
				        sendFileContent(response, "./fav/fav.html", "text/html");
				//				sendFileContent(response, "index.html", "text/html");

				      }



				 	}

	else if(/^\/[a-zA-Z0-9\/]*.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}
	else if(/^\/[a-zA-Z0-9\/]*.css$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}
	else if(/^\/[a-zA-Z0-9\/-/]*.bundle.min.js$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/javascript");
  }
  else if(/^\/[a-zA-Z0-9\-/]*.css$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/css");
  }
  else if(/^\/[a-zA-Z0-9\/-]*.min.css$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/css");
  }
  else if(/^\/[a-zA-Z0-9\/-/]*.jpg$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "image/jpg");
  }
  else if(/^\/[a-zA-Z0-9-._\/]*.min.js$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/javascript");
  }
  else if(/^\/[a-zA-Z0-9-]*.min.css.map$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/map");
  }
  else if(/^\/[a-zA-Z0-9\/-/]*.min.js.map$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/map");
  }
  else if(/^\/[a-zA-Z0-9\/-/]*.css.map$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/map");
  }
  else if(/^\/[a-zA-Z0-9\/-/]*.png$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "image/png");
  }
  else if(/^\/[a-zA-Z0-9\/-/]*.ico$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/ico");
  }
  else if(/^\/[a-zA-Z0-9\/-/?]*.ttf$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/font");
  }
  else if(/^\/[a-zA-Z0-9\/-/?]*.woff$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/woff");
  }
  else if(/^\/[a-zA-Z0-9\/-/?]*.woff2$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/woff2");
  }
	else if(/^\/[a-zA-Z0-9\/-/?]*.map$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/woff2");
  }
	else if(/^\/[a-zA-Z0-9\/-/?]*.map$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/woff2");
  }
	else if(/^\/[a-zA-Z0-9\/-/?]*.slim.min.map$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/woff2");
  }
	else if(/^\/[a-zA-Z0-9\/-/?]*.slim.min.js$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/woff2");
  }
	else if(/^\/[a-zA-Z0-9\/-/?]*.slim.js$/.test(request.url.toString())) {
      sendFileContent(response, request.url.toString().substring(1), "text/woff2");
  }
	else{
		console.log("Requested URL is: " + request.url);
		response.end();
	}
}).listen(9999)

function sendFileContent(response, fileName, contentType){
	fs.readFile(fileName, function(err, data){
		if(err){
			response.writeHead(404);
			response.write("Not Found!");
		}
		else{
			response.writeHead(200, {'Content-Type': contentType});
			response.write(data);
		}
		response.end();
	});
}
